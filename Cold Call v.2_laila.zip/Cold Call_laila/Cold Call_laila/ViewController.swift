//
//  ViewController.swift
//  Cold Call_laila
//
//  Created by administrator on 03/12/2021.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var NameLabel: UILabel!
    
    @IBOutlet weak var NumberLabel: UILabel!
    
    var Name_Array: [String] = ["Laila", "Ali", "Hassan", "Manal","Zainab", "Hssune", "Mona"]
    
    @IBAction func ColdCallButton(_ sender: UIButton) {
        
        NameLabel.text = Name_Array[Int.random(in: 0...(Name_Array.count - 1))]
        
        let Random_Number = Int.random(in: 1...5)
        if Random_Number == 1 || Random_Number == 2 {
            NumberLabel.textColor = UIColor.red
            NumberLabel.text = String(Random_Number)
        }
        else if Random_Number == 3 || Random_Number == 4 {
            NumberLabel.textColor = UIColor.orange
            NumberLabel.text = String(Random_Number)
        }
        else{
            NumberLabel.textColor = UIColor.green
            NumberLabel.text = String(Random_Number)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}
