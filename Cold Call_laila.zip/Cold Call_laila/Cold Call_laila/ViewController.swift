//
//  ViewController.swift
//  Cold Call_laila
//
//  Created by administrator on 03/12/2021.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var NameLabel: UILabel!
    
    var Name_Array: [String] = ["Laila", "Ali", "Hassan", "Manal","Zainab", "Hssune", "Mona"]
    
    @IBAction func ColdCallButton(_ sender: UIButton) {
        
        NameLabel.text = Name_Array[Int.random(in: 0...(Name_Array.count - 1))]
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

